import { Component,signal,computed,Input,input } from '@angular/core';

//import {DUMMY_USERS} from '../dummy-users';

//const randomIndex = Math.floor(Math.random()*DUMMY_USERS.length);

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent {

  // We can accept input via signals rather than @Input decorartor
  //@Input({required :true}) avatar!: string ; //configuration options - required, alias, transform
  //@Input({required :true}) name!: string ; 

  avatar = input.required<string>();  // <> - generic syntax in typescript
  name = input.required<string>(); // input signals are read only (only outside of user component. But cannot change value from user component)


// assigning ! means from outside, we will be setting a string value from outside
 // selectedUser = signal(DUMMY_USERS[randomIndex]); // this is public, private - only available in class

  // state data - change in UI upon clicking

 // get imagePath(){
   // return  'assets/users/'+this.avatar; //execute property as a function

  //}

  imagePath = computed(()=>{ return 'assets/users/'+this.avatar;});

  onSelectUser(){

    //const randomIndex = Math.floor(Math.random()*DUMMY_USERS.length); //locally scoped const random user. Change detection works by zone.js. Detects all possible change to components 
   // this.selectedUser.set(DUMMY_USERS[randomIndex]);
    
    //this.selectedUser = DUMMY_USERS[randomIndex];
}
}
